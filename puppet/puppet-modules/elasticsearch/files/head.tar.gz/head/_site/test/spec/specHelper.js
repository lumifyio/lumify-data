// find *Spec.js files in the src directory next to the corresponding source file
